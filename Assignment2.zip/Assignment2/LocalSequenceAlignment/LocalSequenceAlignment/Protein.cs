﻿namespace SequenceAlignment
{
  public class Protein
  {
    public string name;
    public string sequence;

    public Protein(string name, string seq) {
      this.name = name;
      this.sequence = seq;
    }
  }
}
